A beginner guide to building visualisations on the web with D3.js - Part I
===============================================================================

This repository contains code for the D3.js intro tutorial here - 

Structure:
---------

- index.html - Code file for Tasks 1,2 and 3
- svg.html - Code file for Task 4
- simplebarchart.html - Code file for "Building with D3"

