Experiments with D3.js
=======================

1. start server:
------------
	
	./server

2. goto the url :
-----------------

http://localhost:8000

D3.js source file:
-----------------

`d3.min.js`

